# Vita Learning - Setup Checklist

Track your progress through the setup process.

---

## Pre-Setup (Computer Prep)

- [ ] Install Node.js v16+ (https://nodejs.org)
- [ ] Install PostgreSQL (https://www.postgresql.org/download)
- [ ] Install Git (https://git-scm.com)
- [ ] Create GitHub account (https://github.com)

---

## Local Setup (5 minutes)

### Phase 1: Environment

- [ ] Clone repository (or download ZIP)
- [ ] `cd vita-learning`
- [ ] `cp backend/.env.example backend/.env`
- [ ] `cp frontend/.env.example frontend/.env`

### Phase 2: Database

- [ ] Start PostgreSQL (`brew services start postgresql` on Mac)
- [ ] Create database: `createdb vita_learning`
- [ ] Update `backend/.env` with DB credentials:
  - [ ] `DB_USER=postgres`
  - [ ] `DB_PASSWORD=your_password` (from PostgreSQL install)
  - [ ] Keep other DB values default

### Phase 3: Backend

- [ ] `cd backend && npm install` (takes 1-2 min)
- [ ] Initialize database: See QUICKSTART.md
- [ ] `npm run dev` (should say "🚀 Vita Learning server running on port 5000")

### Phase 4: Frontend

- [ ] Open new terminal
- [ ] `cd frontend && npm install` (takes 1-2 min)
- [ ] `npm run dev` (should say "VITE v5.0.0 ready in...")
- [ ] Open http://localhost:3000 in browser

---

## Test Local Setup

- [ ] Click "Sign Up"
- [ ] Create account: `test@example.com` / `password123`
- [ ] Select role: "Student"
- [ ] See Math/ELA subjects
- [ ] Click Math → See standards
- [ ] Click standard → See skills
- [ ] Click skill → "Practice" button
- [ ] Answer 1 question → See "Correct!" or "Incorrect"
- [ ] Go back to dashboard → See progress

---

## GitHub Setup (For Deployment)

- [ ] Create GitHub account (if don't have one)
- [ ] Create new GitHub repository named `vita-learning`
- [ ] `cd vita-learning` (your local folder)
- [ ] `git init`
- [ ] `git add .`
- [ ] `git commit -m "Vita Learning MVP"`
- [ ] `git remote add origin https://github.com/YOUR_USERNAME/vita-learning.git`
- [ ] `git branch -M main`
- [ ] `git push -u origin main`
- [ ] Verify on GitHub: https://github.com/YOUR_USERNAME/vita-learning

---

## Railway Deployment (10 minutes)

### Account Setup

- [ ] Go to https://railway.app
- [ ] Click "Login with GitHub"
- [ ] Authorize Railway
- [ ] Create new project

### Database Setup

- [ ] Click "+ Provision PostgreSQL"
- [ ] Name it: `vita-learning-db`
- [ ] Railway creates automatically

### Backend Deployment

- [ ] Click "+ New Service"
- [ ] Select GitHub Repo → Choose `vita-learning`
- [ ] Root Directory: `backend`
- [ ] Build Command: `npm install`
- [ ] Start Command: `npm start`
- [ ] Add Variables:
  - [ ] `NODE_ENV=production`
  - [ ] `JWT_SECRET=your_secret_key_12345`
  - [ ] `PORT=5000`
- [ ] Click Deploy
- [ ] Wait 2-3 minutes
- [ ] Copy **Backend URL** (looks like: `https://xxx.railway.app`)

### Initialize Database on Railway

- [ ] In Railway, click Backend Service
- [ ] Click "More" → "Connect via SSH"
- [ ] Run: `npm run migrate` (if script exists) OR...
- [ ] Run: `node --input-type=module -e "import('./src/db/seed.js').then(m => m.seedDatabase())"`
- [ ] Wait for "Database seeded successfully"

### Frontend Deployment

- [ ] Back to Railway dashboard
- [ ] Click "+ New Service"
- [ ] Select GitHub Repo → Same `vita-learning`
- [ ] Root Directory: `frontend`
- [ ] Build Command: `npm run build`
- [ ] Start Command: `npm run preview`
- [ ] Add Variables:
  - [ ] `VITE_API_URL=https://YOUR_BACKEND_URL/api`
  - [ ] (Replace with actual backend URL from step above)
- [ ] Click Deploy
- [ ] Wait 2-3 minutes
- [ ] Copy **Frontend URL**

---

## Verify Deployment

- [ ] Open Frontend URL in browser
- [ ] See Vita Learning login page
- [ ] Sign up: `testuser@example.com` / `password123`
- [ ] Select "Student"
- [ ] See dashboard
- [ ] Practice a question
- [ ] See your score
- [ ] ✅ SUCCESS!

---

## Post-Launch (Next Week)

### Content Expansion

- [ ] Add Science standards
- [ ] Add Social Studies standards
- [ ] Create 50+ more questions per skill
- [ ] Test with real students

### Feature Additions

- [ ] Implement adaptive difficulty algorithm
- [ ] Add AI question generation (Claude API)
- [ ] Build teacher class assignment
- [ ] Add progress notifications

### Optimization

- [ ] Get student feedback
- [ ] Fix any reported bugs
- [ ] Optimize slow pages
- [ ] Add mobile styling

---

## Troubleshooting Checklist

### Backend won't start

- [ ] Check PostgreSQL is running: `brew services list` (Mac) or Services (Windows)
- [ ] Verify database exists: `psql -l` (should show `vita_learning`)
- [ ] Check `.env` file exists and has correct DB password
- [ ] Try: `npm install` again
- [ ] Check port 5000 isn't already in use

### Frontend won't start

- [ ] Check `.env.example` copied to `.env`
- [ ] Try: `npm install` again
- [ ] Try: `rm -rf node_modules package-lock.json && npm install`
- [ ] Check port 3000 isn't already in use

### Can't login

- [ ] Check backend is running (terminal should show API messages)
- [ ] Check frontend `.env` has correct `VITE_API_URL`
- [ ] Try creating new account instead of login
- [ ] Check browser console for error messages (F12)

### Railway deployment fails

- [ ] Check GitHub repo is public (or Railway has access)
- [ ] Check `.env` files not committed (should be in .gitignore)
- [ ] Check package.json exists in backend/ and frontend/
- [ ] Look at Railway deployment logs for specific errors
- [ ] Try redeploying in Railway dashboard

---

## Contact / Support

If stuck:
1. Check README.md (detailed docs)
2. Check DEPLOYMENT.md (for Railway issues)
3. Check individual `.md` files in project
4. Google the error message
5. Ask in GitHub Issues

---

**You got this! 🚀**

Remember: The hardest part is done. You have a WORKING platform. Everything else is iteration and improvement.

Start with students → Get feedback → Improve features.

Good luck!
