# Vita Learning - Quick Start (TL;DR)

Get running in < 5 minutes.

---

## Prerequisites (Do This Once)

```bash
# 1. Install Node.js
# https://nodejs.org (v16+)

# 2. Install & start PostgreSQL
brew install postgresql
brew services start postgresql

# 3. Create database
createdb vita_learning
```

---

## Run Locally

### Terminal 1: Backend

```bash
cd backend
cp .env.example .env  # Update DB password if needed
npm install
npm run dev
```

### Terminal 2: Database Setup

```bash
cd backend
node --input-type=module -e "import('./src/db/seed.js').then(m => m.seedDatabase())"
```

### Terminal 3: Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

### Terminal 4: Open Browser
```
http://localhost:3000
```

**Login test:**
- Email: `student@example.com` (or signup new)
- Password: `anything`

---

## Deploy to Railway (Free)

```bash
# 1. Commit code
git add .
git commit -m "Vita Learning MVP"
git push origin main

# 2. Go to https://railway.app
# 3. Click: New Project → GitHub Repo → Select vita-learning
# 4. Add PostgreSQL + Variables
# 5. Done! Get live URL

# Get your live link from Railway dashboard
```

---

## Key Files

| File | Purpose |
|------|---------|
| `backend/src/index.js` | Express server |
| `frontend/src/App.jsx` | React main component |
| `backend/src/db/seed.js` | Add sample data |
| `content/minnesota_standards_9th.json` | Curriculum data |

---

## Common Commands

```bash
# Reset everything
rm -rf backend/node_modules frontend/node_modules
rm backend/package-lock.json frontend/package-lock.json
npm install in each

# Kill port (if stuck)
lsof -ti:3000 | xargs kill -9  # Frontend
lsof -ti:5000 | xargs kill -9  # Backend

# Recreate database
dropdb vita_learning && createdb vita_learning

# SSH into Railway server
railway shell
```

---

## Check It Works

1. Open http://localhost:3000
2. Click "Sign Up"
3. Create account as "Student"
4. Browse Math skills
5. Click "Practice"
6. Answer questions
7. See score instantly

✅ If this works, you're done!

---

## Next: Add More Content

Edit `content/minnesota_standards_9th.json`:
- Add more standards
- Add more skills
- Edit `backend/src/db/seed.js` to add questions

Re-run:
```bash
dropdb vita_learning && createdb vita_learning
node --input-type=module -e "import('./src/db/seed.js').then(m => m.seedDatabase())"
```

---

**That's it! Happy teaching! 🎓**
