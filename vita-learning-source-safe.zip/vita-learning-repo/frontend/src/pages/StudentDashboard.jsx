import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { questionsApi, studentApi } from '../services/api';

export default function StudentDashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const [standards, setStandards] = useState([]);
  const [skills, setSkills] = useState([]);
  const [progress, setProgress] = useState(null);
  const [selectedSubject, setSelectedSubject] = useState('Math');
  const [selectedStandard, setSelectedStandard] = useState(null);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchDashboard();
    fetchStandards();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await studentApi.getDashboard();
      setProgress(response.data.progress);
      setStats(response.data.stats);
    } catch (err) {
      console.error('Failed to fetch dashboard:', err);
    }
  };

  const fetchStandards = async () => {
    setLoading(true);
    try {
      const response = await questionsApi.getStandards(selectedSubject, 9);
      setStandards(response.data);
      setSelectedStandard(null);
      setSkills([]);
    } catch (err) {
      console.error('Failed to fetch standards:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchSkills = async (standardId) => {
    setLoading(true);
    try {
      const response = await questionsApi.getSkills(standardId);
      setSkills(response.data);
    } catch (err) {
      console.error('Failed to fetch skills:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectStandard = (standard) => {
    setSelectedStandard(standard);
    fetchSkills(standard.id);
  };

  const handlePractice = (skillId) => {
    navigate(`/practice/${skillId}`);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Vita Learning</h1>
            <p className="text-gray-600">Welcome back, {user?.full_name}!</p>
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg"
          >
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-blue-600">{stats.skills_attempted}</div>
              <div className="text-gray-600">Skills Attempted</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-green-600">{stats.skills_mastered}</div>
              <div className="text-gray-600">Skills Mastered</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-purple-600">
                {Math.round(stats.avg_mastery || 0)}%
              </div>
              <div className="text-gray-600">Average Mastery</div>
            </div>
          </div>
        )}

        {/* Subject Selection */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Select Subject</h2>
          <div className="flex gap-4">
            {['Math', 'English'].map((subject) => (
              <button
                key={subject}
                onClick={() => {
                  setSelectedSubject(subject);
                  setSelectedStandard(null);
                }}
                className={`px-6 py-3 rounded-lg font-semibold transition ${
                  selectedSubject === subject
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-800 border border-gray-300 hover:border-blue-600'
                }`}
              >
                {subject}
              </button>
            ))}
          </div>
        </div>

        {/* Standards */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Standards</h2>
          {loading && <p className="text-gray-600">Loading...</p>}
          {!loading && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {standards.map((standard) => (
                <button
                  key={standard.id}
                  onClick={() => handleSelectStandard(standard)}
                  className={`p-4 text-left rounded-lg border-2 transition ${
                    selectedStandard?.id === standard.id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 bg-white hover:border-blue-600'
                  }`}
                >
                  <div className="font-semibold text-gray-900">{standard.standard_code}</div>
                  <div className="text-sm text-gray-600">{standard.standard_name}</div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Skills */}
        {selectedStandard && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Skills</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skills.map((skill) => {
                const skillProgress = progress?.find((p) => p.skill_id === skill.id);
                const masteryPercent = skillProgress?.mastery_level || 0;
                const isMastered = masteryPercent >= 80;

                return (
                  <div key={skill.id} className="bg-white rounded-lg shadow p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {skill.skill_name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">{skill.description}</p>

                    {skillProgress && (
                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-600">Mastery</span>
                          <span className="font-semibold">{Math.round(masteryPercent)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition ${
                              isMastered ? 'bg-green-600' : 'bg-blue-600'
                            }`}
                            style={{ width: `${masteryPercent}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    <button
                      onClick={() => handlePractice(skill.id)}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-semibold transition"
                    >
                      Practice
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
