import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { questionsApi } from '../services/api';

export default function PracticePage() {
  const { skillId } = useParams();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);
  const [timeSpent, setTimeSpent] = useState(0);
  const [startTime, setStartTime] = useState(null);

  useEffect(() => {
    fetchQuestions();
  }, [skillId]);

  useEffect(() => {
    let interval;
    if (!answered && startTime) {
      interval = setInterval(() => {
        setTimeSpent(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [answered, startTime]);

  const fetchQuestions = async () => {
    try {
      const response = await questionsApi.getQuestions(skillId, 10);
      setQuestions(response.data);
      setStartTime(Date.now());
    } catch (err) {
      console.error('Failed to fetch questions:', err);
    } finally {
      setLoading(false);
    }
  };

  const currentQuestion = questions[currentIndex];

  const handleSelectAnswer = (option) => {
    if (!answered) {
      setSelectedAnswer(option);
    }
  };

  const handleSubmitAnswer = async () => {
    if (!selectedAnswer) return;

    const isCorrect = selectedAnswer.is_correct;
    setAnswered(true);

    if (isCorrect) {
      setScore(score + 1);
    }

    try {
      await questionsApi.submitAnswer(
        currentQuestion.id,
        selectedAnswer.option_text,
        isCorrect,
        timeSpent
      );
    } catch (err) {
      console.error('Failed to submit answer:', err);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setAnswered(false);
      setTimeSpent(0);
      setStartTime(Date.now());
    } else {
      // Quiz complete
      navigate('/');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">Loading questions...</div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">No questions available for this skill.</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-semibold text-gray-900">
              Question {currentIndex + 1} of {questions.length}
            </h2>
            <span className="text-sm text-gray-600">{timeSpent}s</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-lg shadow p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            {currentQuestion?.question_text}
          </h3>

          {/* Answer Options */}
          <div className="space-y-4 mb-8">
            {currentQuestion?.options?.map((option) => (
              <button
                key={option.id}
                onClick={() => handleSelectAnswer(option)}
                disabled={answered}
                className={`w-full p-4 text-left rounded-lg border-2 transition ${
                  selectedAnswer?.id === option.id
                    ? option.is_correct && answered
                      ? 'border-green-600 bg-green-50'
                      : !option.is_correct && answered
                      ? 'border-red-600 bg-red-50'
                      : 'border-blue-600 bg-blue-50'
                    : answered && option.is_correct
                    ? 'border-green-600 bg-green-50'
                    : 'border-gray-200 hover:border-blue-600 bg-white'
                } ${answered ? 'cursor-default' : 'cursor-pointer'}`}
              >
                <div className="flex items-center">
                  <div
                    className={`w-6 h-6 rounded-full border-2 mr-4 flex items-center justify-center ${
                      selectedAnswer?.id === option.id
                        ? 'border-blue-600 bg-blue-600'
                        : 'border-gray-300'
                    }`}
                  >
                    {selectedAnswer?.id === option.id && (
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    )}
                  </div>
                  <span className="font-semibold text-gray-900">{option.option_text}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Explanation */}
          {answered && (
            <div
              className={`p-4 rounded-lg mb-8 ${
                selectedAnswer?.is_correct
                  ? 'bg-green-50 border border-green-200'
                  : 'bg-red-50 border border-red-200'
              }`}
            >
              <div
                className={`font-semibold mb-2 ${
                  selectedAnswer?.is_correct ? 'text-green-900' : 'text-red-900'
                }`}
              >
                {selectedAnswer?.is_correct ? '✓ Correct!' : '✗ Incorrect'}
              </div>
              <p className="text-gray-700">{currentQuestion?.explanation}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-4">
            {!answered ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={!selectedAnswer}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition disabled:opacity-50"
              >
                Submit Answer
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg transition"
              >
                {currentIndex < questions.length - 1 ? 'Next Question' : 'Complete'}
              </button>
            )}
          </div>
        </div>

        {/* Score */}
        <div className="text-center">
          <div className="text-gray-600">
            <strong>{score}</strong> of <strong>{currentIndex + (answered ? 1 : 0)}</strong> correct
          </div>
        </div>
      </div>
    </div>
  );
}
