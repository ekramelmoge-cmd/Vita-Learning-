import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { teacherApi } from '../services/api';

export default function TeacherDashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [students, setStudents] = useState([]);
  const [skillAnalytics, setSkillAnalytics] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    setLoading(true);
    try {
      const response = await teacherApi.getClasses();
      setClasses(response.data);
    } catch (err) {
      console.error('Failed to fetch classes:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectClass = async (classData) => {
    setSelectedClass(classData);
    setLoading(true);
    try {
      const [studentsRes, skillsRes] = await Promise.all([
        teacherApi.getClassAnalytics(classData.id),
        teacherApi.getSkillAnalytics(classData.id)
      ]);
      setStudents(studentsRes.data);
      setSkillAnalytics(skillsRes.data);
    } catch (err) {
      console.error('Failed to fetch analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Vita Learning</h1>
            <p className="text-gray-600">Teacher Dashboard - {user?.full_name}</p>
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg"
          >
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Classes */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Classes</h2>
          {loading && !selectedClass && <p className="text-gray-600">Loading classes...</p>}
          {classes.length === 0 && !loading && (
            <p className="text-gray-600">No classes yet. Create one to get started.</p>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {classes.map((classData) => (
              <button
                key={classData.id}
                onClick={() => handleSelectClass(classData)}
                className={`p-6 text-left rounded-lg border-2 transition ${
                  selectedClass?.id === classData.id
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 bg-white hover:border-blue-600'
                }`}
              >
                <h3 className="text-lg font-semibold text-gray-900">{classData.name}</h3>
                <p className="text-sm text-gray-600">{classData.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Class Analytics */}
        {selectedClass && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              Analytics - {selectedClass.name}
            </h2>

            {/* Student Progress */}
            <div className="mb-12">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Student Progress</h3>
              {loading && <p className="text-gray-600">Loading...</p>}
              {!loading && (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Student
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Questions
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Accuracy
                        </th>
                        <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                          Skills
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {students.map((student) => (
                        <tr key={student.student_id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm text-gray-900">
                            <div className="font-semibold">{student.full_name}</div>
                            <div className="text-xs text-gray-600">{student.email}</div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {student.questions_attempted}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <div className="flex items-center gap-2">
                              <div className="w-24 bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-blue-600 h-2 rounded-full"
                                  style={{ width: `${student.accuracy || 0}%` }}
                                ></div>
                              </div>
                              <span className="font-semibold">{Math.round(student.accuracy || 0)}%</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {student.skills_mastered}/{student.skills_attempted}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Skill Analytics */}
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6">Skill Performance</h3>
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                        Skill
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                        Students
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                        Avg Mastery
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">
                        Mastered
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {skillAnalytics.map((skill) => (
                      <tr key={skill.skill_code} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm text-gray-900">
                          <div className="font-semibold">{skill.skill_name}</div>
                          <div className="text-xs text-gray-600">{skill.skill_code}</div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {skill.students_attempted}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex items-center gap-2">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-green-600 h-2 rounded-full"
                                style={{ width: `${skill.avg_mastery || 0}%` }}
                              ></div>
                            </div>
                            <span className="font-semibold">{Math.round(skill.avg_mastery || 0)}%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {skill.students_mastered}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
