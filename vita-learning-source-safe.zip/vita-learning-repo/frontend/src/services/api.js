import axios from 'axios';
import { useAuthStore } from '../store/authStore';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  signup: (email, password, full_name, role) => 
    api.post('/auth/signup', { email, password, full_name, role })
};

export const questionsApi = {
  getStandards: (subject, grade_level) => 
    api.get('/questions/standards', { params: { subject, grade_level } }),
  getSkills: (standardId) => api.get(`/questions/skills/${standardId}`),
  getQuestions: (skillId, limit = 10) => 
    api.get(`/questions/skill/${skillId}`, { params: { limit } }),
  submitAnswer: (questionId, answerText, isCorrect, timeSpent) =>
    api.post('/questions/submit', { questionId, answerText, isCorrect, timeSpent })
};

export const studentApi = {
  getDashboard: () => api.get('/student/dashboard'),
  getProgress: (skillId) => api.get(`/student/progress/${skillId}`)
};

export const teacherApi = {
  getClasses: () => api.get('/teacher/classes'),
  getClassAnalytics: (classId) => api.get(`/teacher/class/${classId}/analytics`),
  getSkillAnalytics: (classId) => api.get(`/teacher/class/${classId}/skill-analytics`)
};

export default api;
