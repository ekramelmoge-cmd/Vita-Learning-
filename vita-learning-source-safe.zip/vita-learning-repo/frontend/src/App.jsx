import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import StudentDashboard from './pages/StudentDashboard';
import PracticePage from './pages/PracticePage';
import TeacherDashboard from './pages/TeacherDashboard';
import NotFound from './pages/NotFound';

function App() {
  const { user } = useAuthStore();

  return (
    <Router>
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={!user ? <LoginPage /> : <Navigate to="/" />} />
        <Route path="/signup" element={!user ? <SignupPage /> : <Navigate to="/" />} />

        {/* Protected routes */}
        <Route path="/" element={user ? (
          user.role === 'student' ? <StudentDashboard /> : <TeacherDashboard />
        ) : <Navigate to="/login" />} />

        <Route path="/practice/:skillId" element={user && user.role === 'student' ? <PracticePage /> : <Navigate to="/login" />} />

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
