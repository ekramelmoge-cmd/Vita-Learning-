import express from 'express';
import { query } from '../db/connection.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Get teacher's classes
router.get('/classes', authenticateToken, requireRole('teacher'), async (req, res) => {
  try {
    const userId = req.user.id;

    const teacherResult = await query('SELECT id FROM teachers WHERE user_id = $1', [userId]);
    if (teacherResult.rows.length === 0) {
      return res.status(404).json({ error: 'Teacher not found' });
    }
    const teacherId = teacherResult.rows[0].id;

    const result = await query(
      'SELECT * FROM classes WHERE teacher_id = $1 ORDER BY created_at DESC',
      [teacherId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch classes' });
  }
});

// Get class students and their progress
router.get('/class/:classId/analytics', authenticateToken, requireRole('teacher'), async (req, res) => {
  try {
    const { classId } = req.params;

    // Get all students in class
    const studentsResult = await query(
      `SELECT s.id, u.full_name, u.email FROM students s
       JOIN users u ON s.user_id = u.id
       WHERE s.class_id = $1`,
      [classId]
    );

    // Get progress for each student
    const analytics = await Promise.all(
      studentsResult.rows.map(async (student) => {
        const progressResult = await query(
          `SELECT 
            COUNT(*) as questions_attempted,
            COUNT(CASE WHEN is_correct THEN 1 END) as questions_correct,
            ROUND(100.0 * COUNT(CASE WHEN is_correct THEN 1 END) / NULLIF(COUNT(*), 0), 2) as accuracy
           FROM student_answers
           WHERE student_id = $1`,
          [student.id]
        );

        const skillProgressResult = await query(
          `SELECT COUNT(*) as skills_attempted, 
                  COUNT(CASE WHEN mastery_level >= 80 THEN 1 END) as skills_mastered
           FROM student_skill_progress
           WHERE student_id = $1`,
          [student.id]
        );

        return {
          student_id: student.id,
          full_name: student.full_name,
          email: student.email,
          questions_attempted: progressResult.rows[0].questions_attempted || 0,
          questions_correct: progressResult.rows[0].questions_correct || 0,
          accuracy: progressResult.rows[0].accuracy || 0,
          skills_attempted: skillProgressResult.rows[0].skills_attempted || 0,
          skills_mastered: skillProgressResult.rows[0].skills_mastered || 0
        };
      })
    );

    res.json(analytics);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Get skill-level analytics for entire class
router.get('/class/:classId/skill-analytics', authenticateToken, requireRole('teacher'), async (req, res) => {
  try {
    const { classId } = req.params;

    const result = await query(
      `SELECT s.skill_name, s.skill_code,
              COUNT(DISTINCT ssp.student_id) as students_attempted,
              ROUND(AVG(ssp.mastery_level), 2) as avg_mastery,
              COUNT(DISTINCT CASE WHEN ssp.mastery_level >= 80 THEN ssp.student_id END) as students_mastered
       FROM skills s
       LEFT JOIN student_skill_progress ssp ON s.id = ssp.skill_id
       LEFT JOIN students st ON ssp.student_id = st.id
       WHERE st.class_id = $1
       GROUP BY s.id, s.skill_name, s.skill_code
       ORDER BY avg_mastery DESC`,
      [classId]
    );

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch skill analytics' });
  }
});

export default router;
