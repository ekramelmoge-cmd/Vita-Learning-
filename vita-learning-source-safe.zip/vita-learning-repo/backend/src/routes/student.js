import express from 'express';
import { query } from '../db/connection.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Get student dashboard
router.get('/dashboard', authenticateToken, requireRole('student'), async (req, res) => {
  try {
    const userId = req.user.id;

    const studentResult = await query('SELECT id FROM students WHERE user_id = $1', [userId]);
    if (studentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    const studentId = studentResult.rows[0].id;

    // Get student progress
    const progressResult = await query(
      `SELECT ssp.*, s.skill_name, st.standard_name, st.subject
       FROM student_skill_progress ssp
       JOIN skills s ON ssp.skill_id = s.id
       JOIN standards st ON s.standard_id = st.id
       WHERE ssp.student_id = $1
       ORDER BY ssp.last_attempted DESC`,
      [studentId]
    );

    // Get overall stats
    const statsResult = await query(
      `SELECT 
        COUNT(DISTINCT skill_id) as skills_attempted,
        COUNT(DISTINCT CASE WHEN mastery_level >= 80 THEN skill_id END) as skills_mastered,
        AVG(mastery_level)::numeric(10,2) as avg_mastery
       FROM student_skill_progress
       WHERE student_id = $1`,
      [studentId]
    );

    res.json({
      progress: progressResult.rows,
      stats: statsResult.rows[0]
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch dashboard' });
  }
});

// Get student progress for specific skill
router.get('/progress/:skillId', authenticateToken, requireRole('student'), async (req, res) => {
  try {
    const userId = req.user.id;
    const { skillId } = req.params;

    const studentResult = await query('SELECT id FROM students WHERE user_id = $1', [userId]);
    if (studentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    const studentId = studentResult.rows[0].id;

    const result = await query(
      `SELECT ssp.*, s.skill_name FROM student_skill_progress ssp
       JOIN skills s ON ssp.skill_id = s.id
       WHERE ssp.student_id = $1 AND ssp.skill_id = $2`,
      [studentId, skillId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'No progress yet for this skill' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch progress' });
  }
});

export default router;
