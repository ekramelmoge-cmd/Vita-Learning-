import express from 'express';
import { query } from '../db/connection.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all standards
router.get('/standards', async (req, res) => {
  try {
    const { subject, grade_level } = req.query;
    let sql = 'SELECT * FROM standards WHERE 1=1';
    const params = [];

    if (subject) {
      params.push(subject);
      sql += ` AND subject = $${params.length}`;
    }

    if (grade_level) {
      params.push(parseInt(grade_level));
      sql += ` AND grade_level = $${params.length}`;
    }

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch standards' });
  }
});

// Get skills for a standard
router.get('/skills/:standardId', async (req, res) => {
  try {
    const { standardId } = req.params;
    const result = await query(
      'SELECT * FROM skills WHERE standard_id = $1 ORDER BY skill_code',
      [standardId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch skills' });
  }
});

// Get questions for a skill
router.get('/skill/:skillId', async (req, res) => {
  try {
    const { skillId } = req.params;
    const { limit = 10 } = req.query;

    const result = await query(
      `SELECT q.* FROM questions q 
       WHERE q.skill_id = $1 
       ORDER BY RANDOM() 
       LIMIT $2`,
      [skillId, parseInt(limit)]
    );

    // Get answer options for each question
    const questions = await Promise.all(
      result.rows.map(async (q) => {
        const optionsResult = await query(
          'SELECT id, option_text, order_num FROM answer_options WHERE question_id = $1 ORDER BY order_num',
          [q.id]
        );
        return { ...q, options: optionsResult.rows };
      })
    );

    res.json(questions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch questions' });
  }
});

// Submit answer
router.post('/submit', authenticateToken, async (req, res) => {
  try {
    const { questionId, answerText, isCorrect, timeSpent } = req.body;
    const userId = req.user.id;

    // Get student ID
    const studentResult = await query('SELECT id FROM students WHERE user_id = $1', [userId]);
    if (studentResult.rows.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    const studentId = studentResult.rows[0].id;

    // Save answer
    await query(
      `INSERT INTO student_answers (student_id, question_id, answer_text, is_correct, time_spent_seconds)
       VALUES ($1, $2, $3, $4, $5)`,
      [studentId, questionId, answerText, isCorrect, timeSpent || 0]
    );

    // Get skill for this question
    const skillResult = await query(
      'SELECT skill_id FROM questions WHERE id = $1',
      [questionId]
    );
    const skillId = skillResult.rows[0].skill_id;

    // Update student skill progress
    const progressResult = await query(
      'SELECT * FROM student_skill_progress WHERE student_id = $1 AND skill_id = $2',
      [studentId, skillId]
    );

    if (progressResult.rows.length === 0) {
      await query(
        `INSERT INTO student_skill_progress (student_id, skill_id, questions_attempted, questions_correct, last_attempted)
         VALUES ($1, $2, 1, $3, CURRENT_TIMESTAMP)`,
        [studentId, skillId, isCorrect ? 1 : 0]
      );
    } else {
      const progress = progressResult.rows[0];
      const newCorrect = progress.questions_correct + (isCorrect ? 1 : 0);
      const masteryLevel = ((newCorrect / (progress.questions_attempted + 1)) * 100).toFixed(2);

      await query(
        `UPDATE student_skill_progress 
         SET questions_attempted = questions_attempted + 1, 
             questions_correct = $1,
             mastery_level = $2,
             last_attempted = CURRENT_TIMESTAMP
         WHERE student_id = $3 AND skill_id = $4`,
        [newCorrect, masteryLevel, studentId, skillId]
      );
    }

    res.json({ success: true, message: 'Answer recorded' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit answer' });
  }
});

export default router;
