import { query } from './connection.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const seedDatabase = async () => {
  try {
    // Read standards from JSON
    const standardsPath = path.join(__dirname, '../../content/minnesota_standards_9th.json');
    const standardsData = JSON.parse(fs.readFileSync(standardsPath, 'utf-8'));

    for (const standard of standardsData.standards) {
      // Insert standard
      const standardResult = await query(
        `INSERT INTO standards (subject, grade_level, standard_code, standard_name, description)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (standard_code) DO NOTHING
         RETURNING id`,
        [standard.subject, standard.grade_level, standard.standard_code, standard.standard_name, standard.description]
      );

      if (standardResult.rows.length === 0) continue;

      const standardId = standardResult.rows[0].id;

      // Insert skills
      for (const skill of standard.skills) {
        const skillResult = await query(
          `INSERT INTO skills (standard_id, skill_code, skill_name, description)
           VALUES ($1, $2, $3, $4)
           ON CONFLICT (skill_code) DO NOTHING
           RETURNING id`,
          [standardId, skill.skill_code, skill.skill_name, skill.description]
        );

        if (skillResult.rows.length === 0) continue;

        const skillId = skillResult.rows[0].id;

        // Add sample questions
        const sampleQuestions = generateSampleQuestions(skill);
        for (const q of sampleQuestions) {
          const questionResult = await query(
            `INSERT INTO questions (skill_id, question_text, question_type, difficulty_level, explanation)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING id`,
            [skillId, q.question_text, q.question_type, q.difficulty_level, q.explanation]
          );

          const questionId = questionResult.rows[0].id;

          // Add answer options
          if (q.options) {
            for (let i = 0; i < q.options.length; i++) {
              await query(
                `INSERT INTO answer_options (question_id, option_text, is_correct, order_num)
                 VALUES ($1, $2, $3, $4)`,
                [questionId, q.options[i].text, q.options[i].correct, i + 1]
              );
            }
          }
        }
      }
    }

    console.log('✅ Database seeded successfully');
  } catch (err) {
    console.error('❌ Seeding error:', err);
    throw err;
  }
};

function generateSampleQuestions(skill) {
  const questionMap = {
    'A9.1.1.1': [
      {
        question_text: 'Solve: 2x + 5 = 13',
        question_type: 'multiple_choice',
        difficulty_level: 1,
        explanation: 'Subtract 5 from both sides: 2x = 8. Divide by 2: x = 4',
        options: [
          { text: 'x = 4', correct: true },
          { text: 'x = 9', correct: false },
          { text: 'x = 18', correct: false },
          { text: 'x = 2.5', correct: false }
        ]
      },
      {
        question_text: 'Solve: 3x - 7 = 2x + 5',
        question_type: 'multiple_choice',
        difficulty_level: 2,
        explanation: 'Subtract 2x from both sides: x - 7 = 5. Add 7: x = 12',
        options: [
          { text: 'x = 12', correct: true },
          { text: 'x = -2', correct: false },
          { text: 'x = 2', correct: false },
          { text: 'x = -12', correct: false }
        ]
      }
    ],
    'A9.1.1.2': [
      {
        question_text: 'What is the y-intercept of y = 2x + 3?',
        question_type: 'multiple_choice',
        difficulty_level: 1,
        explanation: 'The y-intercept is the value of y when x = 0. In y = 2x + 3, when x = 0, y = 3',
        options: [
          { text: '3', correct: true },
          { text: '2', correct: false },
          { text: '-3', correct: false },
          { text: '0', correct: false }
        ]
      }
    ],
    'A9.1.1.3': [
      {
        question_text: 'What is the slope of the line passing through (0,1) and (2,5)?',
        question_type: 'multiple_choice',
        difficulty_level: 1,
        explanation: 'Slope = (y2-y1)/(x2-x1) = (5-1)/(2-0) = 4/2 = 2',
        options: [
          { text: '2', correct: true },
          { text: '1', correct: false },
          { text: '4', correct: false },
          { text: '0.5', correct: false }
        ]
      }
    ],
    'A9.2.1.1': [
      {
        question_text: 'Solve: x² + 5x + 6 = 0',
        question_type: 'multiple_choice',
        difficulty_level: 2,
        explanation: 'Factor: (x+2)(x+3) = 0. So x = -2 or x = -3',
        options: [
          { text: 'x = -2 or x = -3', correct: true },
          { text: 'x = 2 or x = 3', correct: false },
          { text: 'x = 0 or x = 1', correct: false },
          { text: 'x = -1 or x = -6', correct: false }
        ]
      }
    ],
    'E9.1.1.1': [
      {
        question_text: 'What literary device is used when a character learns something important about themselves?',
        question_type: 'multiple_choice',
        difficulty_level: 1,
        explanation: 'Character development or revelation is when a character learns and grows.',
        options: [
          { text: 'Character Development', correct: true },
          { text: 'Foreshadowing', correct: false },
          { text: 'Metaphor', correct: false },
          { text: 'Irony', correct: false }
        ]
      }
    ],
    'E9.2.1.2': [
      {
        question_text: 'Which sentence uses correct grammar?',
        question_type: 'multiple_choice',
        difficulty_level: 1,
        explanation: 'Subject-verb agreement: "The students are going" is correct.',
        options: [
          { text: 'The students are going to the store.', correct: true },
          { text: 'The students is going to the store.', correct: false },
          { text: 'The students are going to the store?', correct: false },
          { text: 'The student are going to the store.', correct: false }
        ]
      }
    ]
  };

  return questionMap[skill.skill_code] || [
    {
      question_text: `Sample question for ${skill.skill_name}`,
      question_type: 'multiple_choice',
      difficulty_level: 1,
      explanation: 'This is a sample explanation',
      options: [
        { text: 'Correct answer', correct: true },
        { text: 'Incorrect option 1', correct: false },
        { text: 'Incorrect option 2', correct: false },
        { text: 'Incorrect option 3', correct: false }
      ]
    }
  ];
}
