# Vita Learning - Railway Deployment Guide

Deploy Vita Learning to Railway in 10 minutes.

---

## Step 1: Create Railway Account

1. Go to https://railway.app
2. Click "Login with GitHub"
3. Authorize Railway access to your GitHub account
4. Done!

---

## Step 2: Create GitHub Repository

```bash
cd vita-learning

# Initialize git (if not already done)
git init
git add .
git commit -m "Initial commit: Vita Learning MVP"

# Create repo on GitHub
# Go to https://github.com/new
# Name: vita-learning
# Make it public or private

# Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/vita-learning.git
git branch -M main
git push -u origin main
```

---

## Step 3: Deploy Backend to Railway

### Create PostgreSQL Database

1. Go to https://railway.app/dashboard
2. Click **+ New Project**
3. Click **Provision PostgreSQL**
4. Give it a name: `vita-learning-db`
5. Railway creates your database automatically

### Deploy Express Server

1. In Railway dashboard, click **+ New Service**
2. Select **GitHub Repo**
3. Connect your `vita-learning` repo
4. Click **Deploy**
5. Configure:
   - **Build Command**: `npm install && npm run build` (or just `npm install`)
   - **Start Command**: `npm start`
   - **Root Directory**: `backend`

6. Go to **Variables** tab, add:
   ```
   NODE_ENV=production
   PORT=5000
   JWT_SECRET=your_super_secret_key_here
   ```

7. Railway automatically adds database credentials (look for `DATABASE_URL` in Variables)

8. Click **Deploy**
9. Wait 2-3 minutes, grab your **Backend URL** from the service details

---

## Step 4: Initialize Database on Railway

```bash
# SSH into Railway backend
railway shell

# Run migrations
npm run migrate

# Seed database with sample data
node --input-type=module -e "import('./src/db/seed.js').then(m => m.seedDatabase())"

# Exit
exit
```

---

## Step 5: Deploy Frontend to Railway OR Vercel

### Option A: Railway (Simpler)

1. In Railway dashboard, click **+ New Service**
2. Select **GitHub Repo** (same repo)
3. Click **Deploy**
4. Configure:
   - **Build Command**: `npm run build`
   - **Start Command**: `npm run preview`
   - **Root Directory**: `frontend`

5. Go to **Variables** tab, add:
   ```
   VITE_API_URL=https://your-backend-url/api
   ```
   (Replace with actual backend URL from Step 3)

6. Click **Deploy**
7. Wait 2-3 minutes, grab your **Frontend URL**

### Option B: Vercel (Alternative)

```bash
# Install Vercel CLI
npm install -g vercel

cd frontend

# Deploy
vercel

# When prompted:
# - Link to existing project? No
# - Project name? vita-learning-frontend
# - Build Command? npm run build
# - Output Directory? dist
```

---

## Step 6: Verify Deployment

1. Open your **Frontend URL** in browser
2. You should see Vita Learning login page
3. Sign up: test@example.com / password123
4. Select "Student"
5. Browse skills and practice!

---

## Step 7: Post-Deployment Setup

### Connect Backend to Frontend

1. Go to Railway dashboard → **Frontend Service**
2. Click **Variables**
3. Update `VITE_API_URL` to your backend URL:
   ```
   VITE_API_URL=https://your-railway-backend-url/api
   ```
4. Click **Redeploy**

### Add Custom Domain (Optional)

1. Go to **Frontend Service** → **Settings**
2. Click **Add Custom Domain**
3. Enter your domain (e.g., `vitalearning.com`)
4. Railway handles SSL automatically

---

## Troubleshooting

### "Cannot connect to database"
- Check Railway PostgreSQL service is running
- Verify `DATABASE_URL` in backend Variables
- Run `railway shell` and test connection

### "Frontend shows blank page"
- Check browser console for errors
- Verify `VITE_API_URL` in frontend Variables
- Make sure backend URL is correct

### "API returns 401 Unauthorized"
- Regenerate `JWT_SECRET` in backend Variables
- Redeploy both services

### "Deployment stuck"
- Check Deployment Logs in Railway dashboard
- Look for build errors
- Ensure all dependencies are in `package.json`

---

## Monitoring & Logs

### View Backend Logs
1. Railway dashboard → Backend Service
2. Click **Logs** tab
3. See real-time server logs

### View Database Logs
1. Railway dashboard → PostgreSQL Service
2. Click **Logs** tab

### Check Deployments
1. Each service has **Deployments** tab
2. See all previous deployments and rollback if needed

---

## Environment Variables Reference

### Backend (.env on Railway)
```
NODE_ENV=production
PORT=5000
JWT_SECRET=your_secret_key
ANTHROPIC_API_KEY=sk-ant-xxx (optional)
DATABASE_URL=postgres://... (auto-filled by Railway)
```

### Frontend (.env on Railway)
```
VITE_API_URL=https://your-backend-railway-url/api
```

---

## Scaling & Performance

### If backend gets slow:
1. Railway dashboard → Backend Service
2. Click **Settings**
3. Increase **CPU** or **Memory**
4. Click **Save** (auto-redeploys)

### Database optimization:
1. Add indexes to frequently queried columns
2. Monitor slow queries in Railway PostgreSQL logs
3. Scale database if needed

---

## Cost Estimate

| Service | Cost |
|---------|------|
| Backend (Node.js) | $5-10/month |
| Frontend (Vercel free) | Free |
| PostgreSQL Database | $7-12/month |
| **Total** | ~$12-22/month |

---

## Next Steps After Deployment

1. **Add more questions** to content/
2. **Implement adaptive algorithm** (harder Q's for passing students)
3. **Add Science & Social Studies** subjects
4. **Set up email notifications** for students
5. **Create marketing landing page**

---

## Rolling Back Deployments

If something breaks:

```bash
# View deployments
railway services

# Rollback to previous deployment
# Click service → Deployments → Click older deployment → Rollback
```

---

**Congratulations! Vita Learning is now live! 🚀**

Share your link with students and teachers!
