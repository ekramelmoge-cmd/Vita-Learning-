# Vita Learning - AI-Powered Educational Platform

**Vita Learning** is a Minnesota standards-aligned 9th-grade practice platform for Math and ELA. Built with React, Node.js, and PostgreSQL.

---

## 📋 Quick Start (5 minutes)

### Prerequisites
- **Node.js** (v16+): https://nodejs.org
- **PostgreSQL**: https://www.postgresql.org/download
- **Git**: https://git-scm.com

### 1. Clone & Setup

```bash
# Clone repository
git clone https://github.com/ekramelmoge-cmd/vita-learning.git
cd vita-learning

# Copy environment files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

### 2. Database Setup

```bash
# Start PostgreSQL
# On Mac: brew services start postgresql
# On Linux: sudo service postgresql start
# On Windows: PostgreSQL service should auto-start

# Create database
createdb vita_learning

# Update backend/.env with your DB credentials:
DB_USER=postgres
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=vita_learning
```

### 3. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Initialize database and seed with sample data
node src/db/init.js
node --input-type=module -e "import('./src/db/seed.js').then(m => m.seedDatabase())"

# Start server (runs on port 5000)
npm run dev
```

### 4. Frontend Setup (New Terminal)

```bash
cd frontend

# Install dependencies
npm install

# Update .env if needed
# VITE_API_URL=http://localhost:5000/api

# Start dev server (runs on port 3000)
npm run dev
```

### 5. Access the App

Open: **http://localhost:3000**

**Test Credentials:**
- Email: `student@example.com` (use for signup)
- Role: Student or Teacher

---

## 🏗️ Project Structure

```
vita-learning/
├── backend/                 # Node.js + Express API
│   ├── src/
│   │   ├── routes/         # API endpoints
│   │   ├── middleware/     # Auth, error handling
│   │   ├── db/             # Database setup, seeding
│   │   └── index.js        # Express server
│   ├── package.json
│   └── .env.example
│
├── frontend/                # React + Vite
│   ├── src/
│   │   ├── pages/          # Login, Dashboard, Practice
│   │   ├── components/     # Reusable components
│   │   ├── services/       # API calls
│   │   ├── store/          # Zustand state
│   │   └── App.jsx         # Main router
│   ├── index.html
│   ├── vite.config.js
│   └── .env.example
│
├── content/                 # Curriculum data
│   └── minnesota_standards_9th.json
│
└── README.md
```

---

## 🚀 Deploying to Railway

### 1. Create Railway Account
- Go to https://railway.app
- Sign up with GitHub

### 2. Deploy Backend

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Create new project
railway init

# Set environment variables in Railway dashboard
# Go to Variables tab in Railway UI

# Deploy
git push
```

### 3. Deploy Frontend (Vercel Alternative)

```bash
# Install Vercel CLI
npm install -g vercel

cd frontend

# Deploy
vercel
```

Or use Railway for both:

```bash
# In Railway dashboard, add frontend service
# Connect to GitHub repo
# Set build command: npm run build
# Set start command: npm run preview
```

---

## 📊 Features

### Student Dashboard
- ✅ Browse skills by standard
- ✅ Practice questions with instant feedback
- ✅ Track mastery progress (0-100%)
- ✅ View performance stats

### Teacher Dashboard
- ✅ Monitor student progress
- ✅ View class-wide analytics
- ✅ See which skills students struggle with
- ✅ Track individual student accuracy

### Content
- ✅ Minnesota 9th-grade standards (Math + ELA)
- ✅ 50+ sample questions
- ✅ Multiple choice format
- ✅ Instant answer feedback with explanations

---

## 🔧 Configuration

### Backend (.env)
```
NODE_ENV=development
PORT=5000
DB_USER=postgres
DB_PASSWORD=password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=vita_learning
JWT_SECRET=change_me_in_production
ANTHROPIC_API_KEY=sk-ant-xxx  # For AI question generation (optional)
```

### Frontend (.env)
```
VITE_API_URL=http://localhost:5000/api
```

---

## 🎯 Next Steps (Phase 2)

### Week 2-3: Expand Content
- [ ] Add 500+ curated questions per skill
- [ ] Add Science & Social Studies
- [ ] Implement question difficulty scaling

### Week 4: Smart Features
- [ ] Adaptive algorithm (harder Q's if passing)
- [ ] AI question generation (Claude API)
- [ ] Advanced analytics dashboards

### Week 5+: Polish
- [ ] Mobile responsive design
- [ ] Teacher class assignment feature
- [ ] Student progress notifications
- [ ] Cert badges for mastery

---

## 📚 Tech Stack

| Component | Technology |
|-----------|-----------|
| Frontend | React 18, TypeScript, TailwindCSS, Vite |
| Backend | Node.js, Express, PostgreSQL |
| Auth | JWT (jsonwebtoken) |
| State | Zustand |
| Deployment | Railway, Vercel |

---

## 🔐 Security Notes

- ⚠️ Change `JWT_SECRET` in production
- ⚠️ Use HTTPS in production
- ⚠️ Set `NODE_ENV=production` on live servers
- ⚠️ Never commit `.env` files
- ⚠️ Use strong database passwords

---

## 📞 Support

### Common Issues

**"Cannot connect to PostgreSQL"**
- Ensure PostgreSQL is running: `brew services list`
- Check credentials in `.env`
- Verify database exists: `psql -l`

**"Port 5000 already in use"**
```bash
# Change PORT in backend/.env
# Or kill the process: lsof -ti:5000 | xargs kill -9
```

**"Module not found errors"**
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

---

## 📄 License

MIT - Feel free to use for educational purposes

---

## 🚀 Built with ❤️ for Minnesota 9th Graders

Questions? Check the issues or reach out!
